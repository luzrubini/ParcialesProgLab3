<?php
require_once "./clases/Empleado.php";

$auxReturn = new stdClass();
$auxReturn->Exito = false;
$auxReturn->Mensaje = "No hay alta";

$pais = isset($_POST['perfil']) ? $_POST['perfil'] : NULL;
$legajo = isset($_POST['legajo']) ? $_POST['legajo'] : NULL;
$clave = isset($_POST['clave']) ? $_POST['clave'] : NULL;
$alta = ($pais != "" && $legajo != "" && $clave !="") ? true : false;

if($alta) {
    $ufologo = new Empleado($pais,$legajo,$clave);
    $objJson=$ufologo->GuardarEnArchivo();
    $auxReturn->Exito = true;
    $auxReturn->Mensaje = "Se ha guardado en el archivo desde AltaEmpleado";
}
echo json_encode($auxReturn);


