  
<?php
$legajoJson = isset($_GET['legajo']) ? $_GET['legajo'] : NULL;
$retornoJson = new stdClass();
$retornoJson->Exito=false;
$retornoJson->Mensaje="No se pudo acceder a la cookie";
$obj = json_decode($legajoJson);
$nombreCookie = str_replace(".", "_", $obj->{'legajo'});
if(isset($_COOKIE[$nombreCookie])) {
    $retornoJson->Exito = true;
    $retornoJson->Mensaje = $_COOKIE[$nombreCookie];
}
echo json_encode($retornoJson);
