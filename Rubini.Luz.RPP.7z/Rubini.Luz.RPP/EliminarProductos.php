<?php
require_once 'clases/Productos.php';
require_once 'clases/AccesoDatos.php';
if(isset($_GET["codBarra"]))
{
    $id=$_GET["codBarra"];
    $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        
        $consulta =$objetoAccesoDato->RetornarConsulta("SELECT * FROM productos WHERE codigo_barra=$id");
        $consulta->execute();
        
        if($consulta->rowCount()>0)
        echo "El ovni existe en la base de datos";
        else
        echo "El ovni No Existe";
}

if(isset($_POST["accion"])=="borrar")
{
    $id=$_POST["codBarra"];
    $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        
        $consulta =$objetoAccesoDato->RetornarConsulta("SELECT * FROM productos WHERE codigo_barra=$id");
        $consulta->execute();
        if($consulta->rowCount()>0)
        {
            $ovniBD=$consulta->fetchAll(PDO::FETCH_CLASS,'Producto');
            
            $ovni=new Producto($ovniBD[0]->tipo,$ovniBD[0]->planetaOrigen,$ovniBD[0]->velocidad,$ovniBD[0]->foto);
            
            if($ovni->Eliminar())
            {
                $ovni->GuardarEnArchivo($id);
                header('Location: Listado.php');
            }
            else
                echo '{"exito":FALSE,"mensaje":"No se pudo borrar"}';
        }
        else
            echo '{"exito":FALSE,"mensaje":"El ovni no existe o ha sido borrado"}';
}