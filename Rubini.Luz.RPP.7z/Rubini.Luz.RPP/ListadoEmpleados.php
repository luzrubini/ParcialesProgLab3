<?php
require_once "./clases/Empleados.php";

class Listado 
{
    public static function CrearListadoJson() 
    {
        $auxReturn = "[";
        $auxArray = Empleado::TraerTodos();
        foreach ($auxArray as $ufologo) 
        {
            $auxReturn.= $ufologo->ToJson().",";
        }
        //
        $auxReturn .= "]";
        return $auxReturn;
    }
}

echo Listado::CrearListadoJson();