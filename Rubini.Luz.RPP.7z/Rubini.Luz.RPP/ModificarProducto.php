<?php
require_once 'clases/Productos.php';
$id=$_POST["id"];
$tipo=$_POST["codBarra"];
$velocidad=$_POST["descripcion"];
$planeta=$_POST["precio"];
$foto=$_FILES["foto"]["name"];


$imagen=$ovni->id.".".$ovni->planetaOrigen.".modificado.".date("His") . ".jpg";
$ovni->pathFoto=$imagen;
$destino="productosmodificados/".$imagen;
$ovni=new Producto($tipo,$planeta,$velocidad,$imagen);
if($ovni->Modificar($id))
{  
    if (move_uploaded_file($_FILES["foto"]["tmp_name"], $destino))
    {
        header('Location:Listado.php');
    }
    else
    echo '{"exito":FALSE,"mensaje":"No se pudo modificar"}';
}
else
echo '{"exito":FALSE,"mensaje":"No se pudo modificar"}';