<?php
require_once "./clases/Productos.php";
$tipo = isset($_POST['codBarra']) ? $_POST['codBarra'] : NULL;
$velocidad = isset($_POST['precio']) ? $_POST['precio'] : NULL;
$planeta = isset($_POST['descripcion']) ? $_POST['descripcion'] : NULL;

$ovni = new Producto($tipo,$planeta,$velocidad);

$arrayOvnis= $ovni->Traer();
if($ovni->Existe($arrayOvnis))
{
    echo "El producto ya existe en la base de datos";
}
else
{


    $nombreAGuardar=$tipo . "." . $planeta . "." . date("Gis") . ".jpg";
    $destino = "productos/imagenes/" . $nombreAGuardar;
    $ovniFinal = new Producto($tipo,$planeta,$velocidad,$nombreAGuardar);
   
    if($ovniFinal->Agregar())
    {
        
        if(move_uploaded_file($_FILES["foto"]["tmp_name"],$destino))
        {
            header('Location:Listado.php');
            
 
        }
        else
        {
            echo "no se pudo agregar la foto";
        }
        
    }
    else
    {
        echo "no se pudo agregar en la base de datos";
    }
   
}
