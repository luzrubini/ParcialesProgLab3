<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Listado</title>
</head>
<body>
    <div>
    <table border=1>
        <thead>
            <tr>
                <td>Codigo de Barra</td>
                <td>Precio</td>
                <td>Precio con IVA</td>
                <td>Velocidad</td>
                <td>Imagen</td>
            </tr>
        </thead>    
    <?php
    require_once "./clases/Productos.php";
    $ovni = new Producto();
    $arrayOvni = $ovni->Traer();
    if($arrayOvni!==null && count($arrayOvni)!==0)
    {
        foreach($arrayOvni as $ov)
        {
            echo "<tr>";
            echo "<td>";
            echo $ov->tipo;
            echo "</td>";
            echo "<td>";
            echo $ov->velocidad;
            echo "</td>";
           
            echo "<td>";
            echo $ov->CalcularIVA();
            echo "</td>";
            echo "<td>";
            echo $ov->planetaOrigen;
            echo "</td>";
            echo "<td>";
            if($ov->pathFoto != "")
            {
                if(file_exists("productos/imagenes/".$ov->pathFoto)) {
                    
                    echo '<img src="productos/imagenes/'.$ov->pathFoto.'" alt=productos/imagenes/"'.$ov->pathFoto.'" height="100px" width="100px">'; 
                  
                }
                elseif (file_exists("productosmodificados/".$ov->pathFoto)) {
                    echo '<img src="productosmodificados/'.$ov->pathFoto.'" alt=productosmodificados/"'.$ov->pathFoto.'" height="100px" width="100px">'; 
                }
                else 
                {
                   echo 'no hay imagen '.$ov->pathFoto; 
                }
            }
            echo "</td>";
            echo "</tr>";
            
        }
    }
    ?>
    </table>
</div>
 
    
</body>
</html>