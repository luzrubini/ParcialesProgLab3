<?php
require_once "./clases/Productos.php";
$tipo = isset($_POST['codBarra']) ? $_POST['codBarra'] : NULL;
$velocidad = isset($_POST['precio']) ? $_POST['precio'] : NULL;
$planeta = isset($_POST['descripcion']) ? $_POST['descripcion'] : NULL;

$objJson= new stdClass();
$objJson->Exito=false;
$objJson->Mensaje="No se pudo agregar";

$nombreAGuardar=$tipo . "." . $planeta . "." . date("Gis") . ".jpg";
$destino = "productos/imagenes/" . $nombreAGuardar;
$ovniFinal = new Producto($tipo,$planeta,$velocidad,$nombreAGuardar);
if($ovniFinal->Agregar())
{
    move_uploaded_file($_FILES["foto"]["tmp_name"],$destino);
    $objJson->Exito=true;
    $objJson->Mensaje="Se pudo agregar en base de datos";
}
echo json_encode($objJson);