<?php
require_once "./clases/Productos.php";
$ovniJson = isset($_POST['producto']) ? $_POST['producto'] : NULL;
$obj = json_decode($ovniJson);

$ovni = new Producto($obj->{'codBarra'},$obj->{'descripcion'},$obj->{'precio'},$obj->{'foto'});
$objJson= new stdClass();
$objJson->Exito=false;
$objJson->Mensaje="No se pudo agregar";
if($ovni->Agregar())
{
    $objJson->Exito=true;
    $objJson->Mensaje="Se pudo agregar en base de datos";
}
echo json_encode($objJson);