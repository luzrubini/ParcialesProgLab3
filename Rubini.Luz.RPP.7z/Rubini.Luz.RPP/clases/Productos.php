<?php
require_once "IParte2.php";
require_once "AccesoDatos.php";

class Producto implements IParte2
{
    #atributos
    public $tipo;
    public $velocidad;
    public $planetaOrigen;
    public $pathFoto;


    public function __construct($tipo = null, $planetaOrigen = null, $velocidad = null, $pathFoto = null)
    {
     $this->tipo = $tipo != null ? $tipo : "";
     $this->velocidad = $velocidad != null ? $velocidad : "";
     $this->planetaOrigen = $planetaOrigen != null ? $planetaOrigen : "";
     $this->pathFoto = $pathFoto != null ? $pathFoto : "";
    }

    public function ToJson()
    {
        $auxJson = new stdClass();
        $auxJson->tipo = $this->tipo;
        $auxJson->velocidad = $this->velocidad;
        $auxJson->planeta = $this->planetaOrigen;
        $auxJson->foto = $this->pathFoto;
        return json_encode($auxJson);
    }
    public function Agregar()
    {
        $objetoDatos =AccesoDatos::DameUnObjetoAcceso();
        $consulta =$objetoDatos->RetornarConsulta("INSERT INTO productos (codigo_barra, descripcion, precio, foto)"
                                                    . "VALUES(:codigo_barra, :descripcion, :precio, :foto)"); 
        
        $consulta->bindValue(':codigo_barra', $this->tipo, PDO::PARAM_STR);
        $consulta->bindValue(':precio', $this->velocidad, PDO::PARAM_INT);
        $consulta->bindValue(':descripcion', $this->planetaOrigen, PDO::PARAM_STR);
        $consulta->bindValue(':foto', $this->pathFoto, PDO::PARAM_STR);
        return $consulta->execute();
    }

    public function Traer()
    {
        $ovnis = array();
        $objetoDatos = AccesoDatos::DameUnObjetoAcceso();
        $consulta = $objetoDatos->RetornarConsulta('SELECT * FROM productos');
        $consulta->execute();

        while($fila = $consulta->fetch())
        {
          $ovni= new Producto($fila[1],$fila[2],$fila[3],$fila[4]);
          array_push($ovnis,$ovni);
        }
        return $ovnis;
 
    }

    public function CalcularIVA()
    {
        return $this->velocidad * 1.21;
    }

    public function Existe($arrayOvnis)
    {
        $retorno = false;
        foreach($arrayOvnis as $ovni)
        {
            if($this->ToJson()==$ovni->ToJson())
            {
                $retorno=true;
            }
        }
        return $retorno;
    }
    public function Modificar($id)
    {
        $retorno=FALSE;
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $tipo=$this->tipo;  $velocidad=$this->velocidad;    $planeta=$this->planetaOrigen;
        $foto=$this->pathFoto;
        $consulta =$objetoAccesoDato->RetornarConsulta("UPDATE `productos` SET `codigo_barra`='$tipo', 
                                                            `descripcion`='$velocidad', 
                                                            `precio`='$planeta',
                                                            `foto`='$foto' WHERE `id`=$id");
        $consulta->execute();
        
        if($consulta->rowCount()>0)
            $retorno=TRUE;
        
        
        return $retorno;
    }
    public function Eliminar()
    {
        $retorno=FALSE;
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $foto=$this->pathFoto;
        
        $consulta =$objetoAccesoDato->RetornarConsulta("DELETE FROM producto WHERE foto='$foto'");
        $consulta->execute();
        if($consulta->rowCount()>0)
            $retorno=TRUE;
        return $retorno;
    }
    /*public function GuardarEnArchivo($id)
    {
        $ar = fopen("ovnis_borrados.txt", "a");
        
        $imagen=$id.".".$this->tipo.".borrado.".date("His") . ".jpg";
        $destino="ovnisBorrados/".$imagen;
        $texto=$this->tipo." - ".$this->velocidad." - ".$this->planetaOrigen." - ".$imagen."\n";
        $cant = fwrite($ar,$texto );
        rename("ovnis/imagenes/".$this->pathFoto,$destino);
        fclose($ar);
    }
    public static function MostrarBorrados()
    {
        $archivo=fopen("ovnis_borrados.txt", "r");
        $retorno=fread($archivo,filesize("ovnis_borrados.txt"));
        return $retorno;
    }*/

}