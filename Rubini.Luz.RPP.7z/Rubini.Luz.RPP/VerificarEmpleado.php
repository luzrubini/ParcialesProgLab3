<?php
require_once "./clases/Empleado.php";
$pais = isset($_POST['perfil']) ? $_POST['perfil'] : NULL;
$legajo = isset($_POST['legajo']) ? $_POST['legajo'] : NULL;
$clave = isset($_POST['clave']) ? $_POST['clave'] : NULL;           
$auxUfologo = new Empleado($pais, $legajo, $clave);


if(Empleado::VerificarExistencia($auxUfologo))
{
    $auxJson = json_decode($auxUfologo->ToJson());
    $auxLegajo = str_replace(".", "_", $auxJson->legajo);
    setcookie($auxLegajo, date("YmdGis") , time()+360);
    header("location:ListadoUfologo.php");
}
else
{
    $retorno = new stdClass();
    $retorno->Exito=false;
    $retorno->Mensaje="El empleado no existe";
    echo json_encode($retorno);
}

