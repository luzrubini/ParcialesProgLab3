<?php
require_once "./clases/Productos.php";
$ovniJson = isset($_POST['producto']) ? $_POST['producto'] : NULL;
$obj = json_decode($ovniJson);


$objJson= new stdClass();
$objJson->Exito=false;
$objJson->Mensaje="No se pudo agregar";

$nombreAGuardar=$obj->{'codBarra'} . "." . $obj->{'descripcion'} . "." . date("Gis") . ".jpg";
$destino = "productos/imagenes/" . $nombreAGuardar;
$ovniFinal = new Producto($obj->{'codBarra'},$obj->{'descripcion'},$obj->{'precio'},$nombreAGuardar);
if($ovniFinal->Agregar())
{
    move_uploaded_file($_FILES["foto"]["tmp_name"],$destino);
    $objJson->Exito=true;
    $objJson->Mensaje="Se pudo agregar en base de datos";
}
echo json_encode($objJson);