<?php
require_once "./clases/Productos.php";
$ovniJson = isset($_POST['producto']) ? $_POST['producto'] : NULL;
$obj = json_decode($ovniJson);

$ovni = new Producto($obj->{'codBarra'},$obj->{'descripcion'},$obj->{'precio'});

$arrayOvnis= $ovni->Traer();
if($ovni->Existe($arrayOvnis))
{
    echo "El producto ya existe en la base de datos";
}
else
{

    $nombreAGuardar=$tipo . "." . $planeta . "." . date("Gis") . ".jpg";
    $destino = "productos/imagenes/" . $nombreAGuardar;
    $ovniFinal = new Producto($obj->{'codBarra'},$obj->{'descripcion'},$obj->{'precio'},$nombreAGuardar);
   
    if($ovniFinal->Agregar())
    {
        
        if(move_uploaded_file($_FILES["foto"]["tmp_name"],$destino))
        {
            header('Location:Listado.php');
            
 
        }
        else
        {
            echo "no se pudo agregar la foto";
        }
        
    }
    else
    {
        echo "no se pudo agregar en la base de datos";
    }
   
}
echo var_dump($_FILES);