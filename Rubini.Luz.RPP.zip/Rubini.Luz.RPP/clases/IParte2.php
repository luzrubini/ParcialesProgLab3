<?php

interface IParte2
{
    public function Agregar();
    public function Traer();
    public function CalcularIVA();
    public function Existe($arrayOvnis);
    public function Modificar($id);
    public function Eliminar();
}