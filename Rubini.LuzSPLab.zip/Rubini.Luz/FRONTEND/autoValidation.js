$(document).ready(()=> {
    $("#autoForm").bootstrapValidator({
        message: "Campo invalido",
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            modelo: {
                validators: {
                    notEmpty: {
                        message: "El modelo no puede estar vacio"
                    },
                    stringLength: {
                        min: 0,
                        max: 30,
                        message: "El modelo debe contener menos de 30 caracteres"
                    }
                }
            },
            marca: {
                validators: {
                    notEmpty: {
                        message: "La marca no puede estar vacia"
                    },
                    stringLength: {
                        min: 0,
                        max: 30,
                        message: "La Marca debe contener menos de 30 caracteres"
                    }
                }
            },
            color: {
                validators: {
                    notEmpty: {
                        message: 'El campo color es requerido'
                    },
                    stringLength: {
                        inclusive: true,
                        max: 15,
                        message: "El color puede contener 15 caracteres como maximo"
                    }
                }
            },
            precio: {
                validators: {
                    notEmpty: {
                        message: 'El campo precio es requerido'
                    },
            },
        }
    }
    });

    $("#btnEnviar").off('click').click(function () {
        $('#autoForm').bootstrapValidator('revalidateField', 'marca');
        $('#autoForm').bootstrapValidator('revalidateField', 'color');
        $('#autoForm').bootstrapValidator('revalidateField', 'precio');
        $('#autoForm').bootstrapValidator('revalidateField', 'modelo');
    });
});